package in.co.online.Exception;

public class DuplicateRecordException extends Exception{
	private DuplicateRecordException(String msg) {
		super (msg);
	}

}
