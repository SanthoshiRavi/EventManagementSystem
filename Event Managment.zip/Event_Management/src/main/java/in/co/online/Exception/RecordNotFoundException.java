package in.co.online.Exception;

public class RecordNotFoundException extends Exception{

	private RecordNotFoundException(String msg) {
		super (msg);
	}
}
