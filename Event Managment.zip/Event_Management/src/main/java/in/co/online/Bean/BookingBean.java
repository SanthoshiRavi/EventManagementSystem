package in.co.online.Bean;

public class BookingBean extends BaseBean{

	
}
