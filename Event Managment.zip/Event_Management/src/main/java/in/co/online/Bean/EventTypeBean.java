package in.co.online.Bean;

public class EventTypeBean extends BaseBean{

	private String eventname;
	private String description;
	public String getEventname() {
		return eventname;
	}
	public void setEventname(String eventname) {
		this.eventname = eventname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
