package in.co.online.Exception;

public class DatabaseException extends Exception{

	private DatabaseException(String msg) {
		super (msg);
		
	}
}
